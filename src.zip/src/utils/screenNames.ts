enum ScreenNames{
  Home= 'Home',
  Login= 'Login',
  Splash= 'Splash',
  Profile= 'Profile',
  BottomTab= 'BottomTab',
  Tutorial = 'Tutorial',
  Signin= 'SignIn',
  Signup= 'Signup',
  Details='Details',
  Search='Search',
  Setting='Setting',
  Add='Add',
  Notify='Notification',
  Save='Save',
  Category='Category',
  Otp='Otp'
} ;

export {ScreenNames};

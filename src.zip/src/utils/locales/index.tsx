export { default as en } from "./eng.json";
export { default as fr } from "./fr.json";
export { default as hindi } from "./hindi.json";
export { default as german } from "./german.json";
export { default as japan } from "./japanese.json";
export { default as urdu } from "./ur.json";
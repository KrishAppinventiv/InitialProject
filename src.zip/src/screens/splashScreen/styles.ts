import {StyleSheet} from 'react-native';


export default StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  containers: {
    flex: 1,
  },
  flex_1: {
    flex: 1,
    
  },
  imageStyle: {
    height: 181,
    width: 181,
    marginHorizontal:20, 
  },
});


const Images = {
  splash_img: require('./images/splash_img.png'),
  
  tutorial:  require('./images/tutorial.png'),
  
  cooking:  require('./images/cooking.png'),
 
  chef:  require('./images/chef.png'), 
  google:  require('./images/google.png'),
  
  top:require('./images/top.png'),
  backarrow: require('./images/backarrow.png'),
  bookmark: require('./images/bookmark.png'),
  docnotify: require('./images/docnotify.png')
};  

export {Images};
